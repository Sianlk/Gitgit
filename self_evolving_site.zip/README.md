# Self‑evolving property page — single canonical link

This site is the **one link** you can share. It renders from `data.json` and **self‑evolves** via GitHub Actions.

## How it evolves
- **/data.json** holds the facts (price, rent, planning). The site renders from this file.
- Create a **GitHub Issue** titled `update` with a JSON body (examples below) → the Action updates `data.json`, bumps `dateUpdated`, rebuilds Pages, and **pings Google/Bing**.
- A nightly job refreshes `lastmod` to keep crawlers engaged.

## Examples — paste as Issue body

**Update price and rent**
```json
{"askingPriceGBP": 625000, "currentAST": {"perMonthGBP": 2600}, "postWorksRentRange": {"perMonthGBP": [3450, 4000]}}
```

**Add planning ref**
```json
{"planning":[{"ref":"PA/2025/1234","type":"Householder","desc":"36 sqm rear extension","decision":"Granted","date":"2025-08-01"}]}
```

**Change features**
```json
{"property":{"features":["Driveway","Side access","Large garden","Near Tube"]}}
```

## Deploy
1) Host on GitHub Pages.
2) Replace the placeholder URL inside `sitemap.xml` and `robots.txt` with your live Pages URL.
3) Submit sitemap to Google Search Console.

## AVM/SEO
- JSON‑LD (`RealEstateListing`) is injected at runtime with the live values.
- Actions also **ping**: `https://www.google.com/ping?sitemap=<sitemap>` and `https://www.bing.com/ping?sitemap=<sitemap>`.
